package com.mypetlikeit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MypetlikeitApplication {

	public static void main(String[] args) {
		SpringApplication.run(MypetlikeitApplication.class, args);
	}

}
