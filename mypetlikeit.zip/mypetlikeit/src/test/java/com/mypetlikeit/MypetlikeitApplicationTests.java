package com.mypetlikeit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MypetlikeitApplicationTests {

	@Test
	void contextLoads() {
	}

}
